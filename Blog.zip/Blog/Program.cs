﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Blog.Models;
using Blog.DAO;
using NHibernate.Cfg;
using FluentNHibernate.Cfg;
using NHibernate;
using System.Reflection;
using Blog.Infra;

namespace Blog
{
    class Program
    {
        static void Main(string[] args)
        {
           
            using (ISession session = NHibernateHelper.AbreSessao()) {

                
                IList<Post> posts = queryHql.List<Post>();

                foreach (var p in posts) {
                    Console.WriteLine(p.Id + " " + p.Titulo);
                }

                Console.ReadLine();
                //Post post = new Post();
                //post.Titulo = "Outro post";
                //post.Conteudo = "Conteudo	do	post";
                //post.DataPublicacao = DateTime.Now;
                //post.Publicado = true;

                //ITransaction tx = session.BeginTransaction();
                //session.Save(post);
                //tx.Commit();
            }

            Console.ReadLine();

        }
    }
}
