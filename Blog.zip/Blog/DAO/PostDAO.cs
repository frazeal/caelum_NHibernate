﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Blog.Models;
using NHibernate;
using Blog.Infra;

namespace Blog.DAO {
    public class PostDAO {

        public void Adicionar(Post post) 
        {

            using (ISession sessao = NHibernateHelper.AbreSessao()) {
                ITransaction tran = sessao.BeginTransaction();
                sessao.Save(post);
                tran.Commit();
            } // end of using

        } // end of Adicionar()

        public IList<Post> Listar()
        {

            using (ISession sessao = NHibernateHelper.AbreSessao()) {

                string comandoHql = "select p from Post p";
                IQuery queryHql = sessao.CreateQuery(comandoHql);
                return queryHql.List<Post>();    

            }

        } // end of Listar()

        public Post BuscarPorId(int _id) 
        {

            using (ISession sessao = NHibernateHelper.AbreSessao()) {

                return sessao.Get<Post>(_id);

            }

        } // end of BuscarPorId()

        public void Atualizar(Post post) 
        {

            using (ISession sessao = NHibernateHelper.AbreSessao()) {

                ITransaction tran = sessao.BeginTransaction();
                sessao.Merge(post);
                tran.Commit();
            }

        } //end of Atualizar

        public void Apagar(Post post) 
        {
            using (ISession sessao = NHibernateHelper.AbreSessao()) {

                ITransaction tran = sessao.BeginTransaction();
                sessao.Delete(post);
                tran.Commit();
            } 

        } //end of Apagar()

        public int ContarRegistros() 
        {
            String comandoSql = "select COUNT(*) from dbo.POSTS";
            int quantidade = 0;

            using (IDbConnection conexao = ConnectionFactory.CriarConexao())
            using (IDbCommand comando = conexao.CreateCommand()) {
                
                comando.CommandText = comandoSql;

                quantidade = Convert.ToInt32(comando.ExecuteScalar());
            }

            return quantidade;
        }

    } // end of PostDAO

}
