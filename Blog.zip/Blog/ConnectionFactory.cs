﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace Blog {

    public static class ConnectionFactory {

        public static IDbConnection CriarConexao() {

            IDbConnection conexao = new SqlConnection();
            ConnectionStringSettings stringConexao = ConfigurationManager.ConnectionStrings["blog"];
            conexao.ConnectionString = stringConexao.ConnectionString;
            //@"Data Source=(LocalDB)\v11.0;AttachDbFilename=c:\users\aspnet6402\documents\visual studio 2013\Projects\Blog\Blog\Blog.mdf;Integrated Security=True";
            conexao.Open();
            return conexao;

        }
    }
}
